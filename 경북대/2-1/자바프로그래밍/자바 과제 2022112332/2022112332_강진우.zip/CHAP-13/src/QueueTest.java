import java.util.*;

public class QueueTest {
    public static void main(String[] args) throws InterruptedException {
        int time = 10;
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        Queue<Integer> queue = new LinkedList<Integer>();
        for (int i = time; i >= 0; i--) {
            queue.add(i);
            pq.add(i);
        }
        while (!queue.isEmpty()) {
            System.out.println(queue.remove()+ " " + pq.remove());
            Thread.sleep(1000);	// 현재의 스레드를 1초간 재운다.
        }

    }
}