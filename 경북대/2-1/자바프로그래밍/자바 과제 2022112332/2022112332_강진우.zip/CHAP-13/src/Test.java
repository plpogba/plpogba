import java.util.Scanner;

class MyMath<T extends Number> {
    double v=0.0;
    public double getAverage(T[] a){
        for (int i = 0; i < a.length; i++)
            v = v + a[i].doubleValue();
        return v/a.length;
    }
}

public class Test
{
    public static void main(String[] args) {
        Integer[] list = new Integer[3];
        Float[] list1 = new Float[3];
        Scanner sc = new Scanner(System.in);
        for(int i =0;i<3; i++) {
            System.out.print("정수를 입력하시오: ");
            list[i] = sc.nextInt();
        }

        MyMath<Integer> m = new MyMath<Integer>();
        System.out.println("평균값: "+m.getAverage(list));

        for(int i =0;i<3; i++) {
            System.out.print("실수를 입력하시오: ");
            list1[i] = sc.nextFloat();
        }

        MyMath<Float> n = new MyMath<Float>();
        System.out.println("평균값: "+n.getAverage(list1));
    }
}