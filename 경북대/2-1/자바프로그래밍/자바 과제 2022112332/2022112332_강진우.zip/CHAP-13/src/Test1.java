import java.util.ArrayList;

public class Test1 {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("a");
        arrayList.add("b");
        arrayList.add("c");
        arrayList.add("d");
        arrayList.add("e");
        System.out.println("" + arrayList);

        ArrayList<Double> arrayList1 = new ArrayList<Double>();
        arrayList1.add(1.2);
        arrayList1.add(3.2);
        arrayList1.add(4.1);
        arrayList1.add(4.4);
        arrayList1.add(4.2);
        System.out.println("" + arrayList1);
    }
}
