package MiniProject.CHAP13;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


class Monster {
    int x, y, hp;
    Image img;

    Monster(int x, int y, int hp) {
        this.x = x;
        this.y = y;
        this.hp = hp;
        ImageIcon icon = new ImageIcon("monster.png");
        img = icon.getImage();
    }

    public void draw(Graphics g) {
        g.drawImage(img, x, y, null);
    }
}

public class MonsterTest extends JPanel {
    ArrayList<Monster> monsters = new ArrayList<Monster>();

    public MonsterTest(int j) {
        for (int i = 0; i <j*5; i++)
            monsters.add(new Monster((int) (Math.random() * 600), (int) (Math.random() * 400), 100));
    }

    public static void main(String[] args) {
        JFrame f = new JFrame();

        f.setSize(600, 400);
        f.setTitle("Monster Catch Game");

        for(int i = 0 ; i< 5; i++){
            f.add(new MonsterTest(i));
            f.setVisible(true);
        }



    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Monster m : monsters)
            m.draw(g);
    }
}