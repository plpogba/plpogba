package MiniProject.CHAP14;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

class Product {
    int id;
    String name;
    int price;

    public Product(int id, String name, int price) {
        super();
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
    }
}

public class StreamTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Product> list = new ArrayList<Product>();
        list.add(new Product(1, "NoteBook", 100));
        list.add(new Product(2, "TV", 320));
        list.add(new Product(3, "Washing Machine", 250));
        list.add(new Product(4, "Air Conditioner", 500));

        System.out.println("��ǰ�� �˻��Ͻÿ�.");
        System.out.print("��ǰ�� �̸�(*�� ��� ��ǰ�� �ǹ�):");
        String name = sc.nextLine();

        System.out.print("��ǰ�� ���� ����:");
        int priceHigh = sc.nextInt();

        if (name.equals("*")) {
            List<Product> result = list.stream().filter(p -> p.price < priceHigh).collect(Collectors.toList());

            System.out.println(result);
        } else {
            List<Product> result = list.stream().filter(p -> p.price < priceHigh).filter(p -> p.name.equals(name))
                    .collect(Collectors.toList());
            System.out.println(result);

        }
    }
}