package MiniProject.CHAP15;

import java.io.File;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws Exception {
        Scanner sc2 = new Scanner(System.in);
        int cnt=0;
        Scanner sc = new Scanner(new File("seeds.csv"));
        String key = sc2.next();
        sc.useDelimiter(",");
        while (sc.hasNext()) {
            String a = sc.next();

            if(a.equals(key))
                cnt+= 1;

        }
        System.out.println(cnt);
        sc.close();
        sc2.close();
    }
}