package 프로그래밍문제.CHAP13.EX02;

import java.util.Scanner;
import java.util.Arrays;
class MyMath<T extends Number> {
    double v = 0.0;

    public double getAverage(T[] a) {
        for (int i = 0; i < a.length; i++)
            v = v + a[i].doubleValue();
        return v / a.length;
    }
    public T getMiddle(T[] a){
        return a[a.length/2];
    }
}

public class Test {
    public static void main(String[] args) {
        Integer[] list = new Integer[3];

        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            System.out.print("정수를 입력하시오: ");
            list[i] = sc.nextInt();
        }
        Arrays.sort(list);

        MyMath<Integer> m = new MyMath<Integer>();
        System.out.println("평균값: " + m.getAverage(list));
        System.out.println("중앙값: " + m.getMiddle(list));
    }
}