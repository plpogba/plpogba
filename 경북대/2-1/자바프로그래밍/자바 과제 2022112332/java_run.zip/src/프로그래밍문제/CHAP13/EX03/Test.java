package 프로그래밍문제.CHAP13.EX03;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        for(int i = 0 ; i < 10; i++)
            arrayList.add(i);
        System.out.println( arrayList);
    }
}