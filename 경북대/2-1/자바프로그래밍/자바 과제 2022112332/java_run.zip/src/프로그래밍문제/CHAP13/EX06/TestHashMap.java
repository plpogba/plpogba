package 프로그래밍문제.CHAP13.EX06;

import java.util.HashMap;
import java.util.Scanner;

public class TestHashMap {

    public static void main(String args[]) {

        HashMap<String, String> hmCountry = new HashMap<String, String>();
        hmCountry.put("Korea", "Seoul");
        hmCountry.put("USA", "Washington");
        hmCountry.put("Japan", "Tokyo");
        hmCountry.put("China", "Beijing");
        hmCountry.put("UK", "London");
        hmCountry.forEach((key, value) -> {
            System.out.println("Key: " + key + ", Value: " + value);
        });
        Scanner sc = new Scanner(System.in);
        System.out.print("국가 이름을 입력하시오: ");
        String s = sc.nextLine();

        String capital = hmCountry.get(s);
        System.out.println(s + "의 수도: " + capital);
        s = sc.nextLine();
        System.out.println("hashmap has" + s + "?" + hmCountry.containsValue(s));




    }
}