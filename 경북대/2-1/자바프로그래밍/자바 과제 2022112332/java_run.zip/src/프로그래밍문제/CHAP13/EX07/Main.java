package 프로그래밍문제.CHAP13.EX07;

import java.util.LinkedHashMap;
import java.util.Map;

public class Main {

    private static final Integer ONE = new Integer(1);

    public static void main(String[] args) {

        String name[] = {
                new String("Kim"),
                new String("Choi"),
                new String("Park"),
                new String("Kim"),
                new String("Kim"),
                new String("Park")
        };

        Map m = new LinkedHashMap();

        for (int i = 0; i < name.length; i++) {
            Integer freq = (Integer) m.get(name[i]);

            m.put(name[i], (freq == null ? ONE :
                    new Integer(freq.intValue() + 1)));

        }
        System.out.println(m.size() + "개의 이름이 발견되었습니다.");
        System.out.println(m);
    }
}
