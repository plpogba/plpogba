package 프로그래밍문제.CHAP13.EX09;

import java.util.HashSet;

public class Lotto {
    HashSet<Integer> set = new HashSet<Integer>();

    public Lotto() {
        int d;
        for (int i = 0; i < 6; i++) {
            do {
                d = (int) (Math.random() * 44.0 + 1.0);
            } while (set.contains(d));
            set.add(d);
        }
    }

    public static void main(String[] args) {
        Lotto winninglotto = new Lotto();
        int cnt = 0;
        boolean win = false;
        while(!win){
            Lotto buylotto = new Lotto();
            if(buylotto.set.equals(winninglotto.set))
                win = true;
            cnt++;
        }
        System.out.println("times to win lotto: " + cnt);

    }

}