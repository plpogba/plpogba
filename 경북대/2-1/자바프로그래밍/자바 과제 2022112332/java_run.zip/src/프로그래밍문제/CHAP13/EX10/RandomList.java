package 프로그래밍문제.CHAP13.EX10;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class RandomList<T> {
    Random r = new Random();
    String[] sample = {"i", "walk", "the", "line"};
    List<T> list = (List<T>) Arrays.asList(sample);

    public static void main(String[] args) {
        RandomList<String> rl = new RandomList<>();
        String s = rl.toString();

    }

    public void add(T item) {
        list.add(item);
    }

    public T select() {
        int num = r.nextInt(list.size());
        return list.get(num);
    }
    public String toString(){
        System.out.println(this.list);
        return null;
    }
}