package 프로그래밍문제.CHAP14.EX01;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MethodReferenceSqrt {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(new Integer[]{1, 2, 3, 4, 5, 6});

        // 람다식 버전
        Function<Integer, Double> function1 = (num) -> Math.sqrt(num);
        List<Double> collect1 = list.stream().filter(num -> num > 2).map(function1).collect(Collectors.toList());
        System.out.println(collect1);

        // 메소드 참조 버전
        Function<Integer, Double> function2 = Math::sqrt;
        List<Double> collect2 = list.stream().map(function2).collect(Collectors.toList());
        System.out.println(collect2);
    }
}