package 프로그래밍문제.CHAP14.EX04;

interface Square {
    public int getArea(int side);
}

public class AreaOfSquare {
    public static void main(String[] args) {
        Square area = (side) -> {
            return side * side;
        };
        Square cube = side -> {
            return side*side*side;
        };
        System.out.println("정사각형 면적: " + area.getArea(10));
        System.out.println("정육면체 부피: " + cube.getArea(10));

    }
}