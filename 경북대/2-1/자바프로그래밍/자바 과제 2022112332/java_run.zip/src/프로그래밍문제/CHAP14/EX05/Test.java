package 프로그래밍문제.CHAP14.EX05;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Color {
    String name;
    String hexaCode;

    public Color(String name, String hexaCode) {
        super();
        this.name = name;
        this.hexaCode = hexaCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Color [name=" + name + ", hexaCode=" + hexaCode + "]";
    }

    public String getHexaCode() {
        return hexaCode;
    }

    public void setHexaCode(String hexaCode) {
        this.hexaCode = hexaCode;
    }
}

public class Test {

    public static void main(String[] args) {
        List<Color> list = new ArrayList<>();

        Color red = new Color("Red", "#FF0000");
        Color blue = new Color("Blue", "0000FF");
        Color white = new Color("White", "#FFFFFF");
        Color green = new Color("Green", "#008000");

        list.add(red);
        list.add(blue);
        list.add(white);
        list.add(green);
        List<String> resultList = list.stream()
                .map(c -> c.getName())
                .sorted((c1, c2) -> c1.compareTo(c2))
                .collect(Collectors.toList());

        resultList.forEach(System.out::println);
    }
}