package 프로그래밍문제.CHAP14.EX06;

import java.util.function.Function;

public class Test {
    public static void main(String[] args) {
        Function<String, String> func = x -> {
           return x.toUpperCase();
        };
        String apply = func.apply("Hello");
        System.out.println(func.apply("Hello"));
    }
}