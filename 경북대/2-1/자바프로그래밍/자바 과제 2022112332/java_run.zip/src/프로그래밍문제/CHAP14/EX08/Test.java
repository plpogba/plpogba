package 프로그래밍문제.CHAP14.EX08;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
    static List<String> list = Arrays.asList("Kim", "Park", "Lee", "Hello", "World");

    public static String test() {
        String result = list.stream().filter(w -> w.length() < 5).map(String::toLowerCase)
                .collect(Collectors.joining(" "));
        System.out.println(result);
        return result;
    }

    public static void main(String[] args) {
        Test t = new Test();
        System.out.println(t.test());
    }
}