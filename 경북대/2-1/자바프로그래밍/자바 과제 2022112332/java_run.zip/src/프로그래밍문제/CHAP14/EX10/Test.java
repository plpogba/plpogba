package 프로그래밍문제.CHAP14.EX10;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

class Country {
    private String name;
    private int population;
    private double gdp;
    private List<City> cities;
}

class City {
    private String name;
    private int population;
    private String countryName;

    public City(String name, int population, String countryName) {
        super();
        this.name = name;
        this.population = population;
        this.countryName = countryName;
    }

    @Override
    public String toString() {
        return "City [name=" + name + ", population=" + population + ", countryName=" + countryName + "]";
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }
}

public class Test {
    public static void main(String[] args) {
        List<City> cities = Arrays.asList(new City("SEOUL", 1000, "KOREA"), new City("INCHEN", 500, "KOREA"),
                new City("BUSAN", 800, "KOREA"));

        City max = cities.stream().min(Comparator.comparing(City::getPopulation))
                .orElseThrow(NoSuchElementException::new);
        System.out.println(max);

    }
}
