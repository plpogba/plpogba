package 프로그래밍문제.CHAP15.EX01;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws IOException {
        int num2;
        String search;
        Scanner scan = null;
        String name;
        int number;
        String tel;
        PrintWriter in = new PrintWriter(new FileWriter("contacts.txt"));
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.print("이름, 학번, 전화 번호를 입력하시오: ");
            name = s.next();
            if (name.equals("quit")) break;
           try{
               number = Integer.parseInt(s.next());
               tel = s.next();
           }catch (Exception e){
               System.out.println("not a number");
           }

            in.flush();
        }
        System.out.println("contacts.txt에 저장되었습니다.");
        if (in != null)
            in.close();
    }
}