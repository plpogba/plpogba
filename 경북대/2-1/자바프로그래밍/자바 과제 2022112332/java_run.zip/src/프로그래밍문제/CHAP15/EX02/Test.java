package 프로그래밍문제.CHAP15.EX02;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Random ran = new Random();
        int number = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("난수의 최대값: ");
        int max = sc.nextInt();

        System.out.print("한 줄에 출력하는 난수의 개수: ");
        int perline = sc.nextInt();

        sc.nextLine();
        System.out.println("파일 이름: ");
        String name = sc.nextLine();

        try (PrintWriter file = new PrintWriter(new BufferedWriter(new FileWriter(name)));) {
            int count = (int)(Math.random() * 1000);
            for (int i = 0; i < count; i++) {
                number = ran.nextInt(max) + 1;
                file.print(number + " ");
                if (i % perline == 0 && i != 0)
                    file.print("\n");
                if (i == 0 && perline == 1)
                    file.print("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}