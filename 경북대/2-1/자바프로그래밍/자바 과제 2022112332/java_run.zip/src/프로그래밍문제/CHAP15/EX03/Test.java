package 프로그래밍문제.CHAP15.EX03;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Test {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        try {
            FileReader fr = new FileReader("input.txt");
            BufferedReader br = new BufferedReader(fr);
            while (true) {
                String line = br.readLine();
                if (line == null)
                    break;
                line = line.replaceAll("\\s+", "");
                int value = Integer.parseInt(line);
                list.add(value);
            }
            fr.close();
            Collections.sort(list);
            FileWriter fr1 = new FileWriter("output.txt");
            PrintWriter br1 = new PrintWriter(fr1);
            for (int k = 0; k < list.size(); k++) {
                br1.println(list.get(k));
            }
            br1.flush();
            fr1.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}