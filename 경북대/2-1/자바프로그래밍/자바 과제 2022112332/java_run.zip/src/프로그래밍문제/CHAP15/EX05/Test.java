package 프로그래밍문제.CHAP15.EX05;

import java.io.*;

public class Test {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("input.txt");
            BufferedReader br = new BufferedReader(fr);
            FileWriter fr1 = new FileWriter("output.txt");
            PrintWriter br1 = new PrintWriter(fr1);
            int counter = 0;
            while (true) {
                counter++;
                String line = br.readLine();
                if (line == null)
                    break;
                br1.println("" + counter + ":" + line);
                System.out.println("" + counter + ":" + line);
            }
            fr.close();
            br1.flush();
            fr1.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}