package 프로그래밍문제.CHAP15.EX06;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws IOException {

        StringBuilder result = new StringBuilder();
        StringBuilder hex = new StringBuilder();
        StringBuilder input = new StringBuilder();
        Scanner sc = new Scanner(System.in);
        System.out.print("입력 파일 이름(이진 파일): ");
        String name = sc.nextLine();

        int count = 0;
        int value;

        try (InputStream inputStream = new FileInputStream(name)) {
            while ((value = inputStream.read()) != -1) {
                hex.append(String.format("%02X ", value));

                if (count == 14) {
                    result.append(String.format("%-60s | %s%n", hex, input));
                    hex.setLength(0);
                    input.setLength(0);
                    count = 0;
                } else {
                    count++;
                }

            }
            if (count > 0) {
                result.append(String.format("%-60s | %s%n", hex, input));
            }

        }
        System.out.println(result);
    }
}