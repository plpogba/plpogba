package 프로그래밍문제.CHAP15.EX07;

import java.io.File;
import java.util.Scanner;
public class Test {
    public static void main(String a[]) {
        Scanner sc = new Scanner(System.in);
        String find = sc.next();
        File file = new File("c:/");
        String[] fileList = file.list();
        for (String name : fileList) {
            System.out.println(name);
            if(name.equals(find))
                System.out.println("found!!");
        }
    }
}