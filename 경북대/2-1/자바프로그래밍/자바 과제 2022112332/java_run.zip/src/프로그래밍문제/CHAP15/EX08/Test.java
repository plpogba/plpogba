package 프로그래밍문제.CHAP15.EX08;

import java.io.*;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.print("검색할 문자열: ");
        String input = sc.nextLine();
        File file = new File("./");
        String[] list = file.list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                if (name.toLowerCase().endsWith(".java")) {
                    return true;
                } else {
                    return false;
                }
            }
        });
        for (String fname : list) {
            File f1 = new File(fname);
            String[] words = null;
            FileReader fr = new FileReader("./" + f1);
            BufferedReader br = new BufferedReader(fr);
            int linecount = 1;
            String s;
            while ((s = br.readLine()) != null) {
                words = s.split(" ");
                for (String word : words) {
                    if (word.equals(input)) {
                        System.out.println("" + fname + " " + linecount + ": " + s);
                    }
                }
                linecount++;
            }
            fr.close();
        }
    }
}