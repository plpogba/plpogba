package 프로그래밍문제.CHAP15.EX10;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        File file = new File("./");
        String ffname = sc.next();
        String[] list = file.list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                if (ffname.equals(name)) {
                    return true;
                } else {
                    return false;
                }
            }
        });
        for (String fname : list) {
            File f1 = new File(fname);
            String[] words = null;
            File f = new File("./" + f1);
            f.delete();
            System.out.println("./" + f1 + "을 삭제하였습니다.");
        }
        System.out.println("총 " + list.length + "개의 파일을 삭제하였습니다. ");
    }
}