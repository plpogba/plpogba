package 프로그래밍문제.CHAP15.EX13;

import java.io.*;

public class Test {

    static void encdec(byte key, String infile, String outfile) throws Exception {
        FileInputStream is = new FileInputStream(infile);
        FileOutputStream os = new FileOutputStream(outfile);

        byte[] data = new byte[1024];
        int read = is.read(data);
        while (read != -1) {
            for (int k = 0; k < read; k++) {
                data[k] ^= key;
            }
            os.write(data, 0, read);
            read = is.read(data);
        }
        os.flush();
        os.close();
        is.close();
    }

    public static void main(String[] args) throws Exception {
        encdec((byte) 23, "test.txt", "test.bin");
        for (int i = 0; i < 255; i++) {
            encdec((byte) i, "test.bin", "test" + i + ".txt");

            File f1 = new File("test" + i + ".txt");
            String[] words = null;
            FileReader fr = new FileReader(f1);
            BufferedReader br = new BufferedReader(fr);
            String s;
            String input = "computer";
            int count = 0;
            while ((s = br.readLine()) != null) {
                words = s.split(" ");
                for (String word : words) {
                    if (word.equals(input)) {
                        System.out.println("키를 찾았음: " + (byte) i);
                        System.exit(0);
                    }
                }
            }
        }

    }
}