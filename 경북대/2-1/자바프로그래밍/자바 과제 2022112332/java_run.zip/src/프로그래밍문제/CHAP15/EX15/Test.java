package 프로그래밍문제.CHAP15.EX15;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Test {

    public static void main(String[] args) throws Exception {

        BufferedReader inputStream = null;
        PrintWriter outputStream = null;

        try {
            outputStream = new PrintWriter(new FileWriter("table.html"));
            String s;
            outputStream.println("<html><head>\r\n"
                    + "<title>2의 거듭제곱</title>\r\n"
                    + "</head>\r\n"
                    + "<body>\r\n"
                    + "<table border cellpadding=5>\r\n"
                    + "<tr><th>2의 거듭제곱</th><th>Value</th></tr>");
            for (int i = 0; i < 10; i++) {
                double squared;
                squared = Math.pow(2.0, (double) i);
                outputStream.println("<tr><td>" + i + "</td><td>" + (int) squared + "</td></tr>");
            }
            outputStream.println("</table>\r\n"
                    + "</body></html>");
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
        }
    }
}