package 프로그래밍문제.CHAP15.EX16;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class MyFrame extends JFrame implements ActionListener {

    String filepath;
    JButton btnNewButton;
    JButton btnNewButton_1;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    /**
     * Create the frame.
     */
    public MyFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 504, 199);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("From:");
        lblNewLabel.setBounds(57, 33, 57, 15);
        contentPane.add(lblNewLabel);

        JLabel lblTo = new JLabel("To:");
        lblTo.setBounds(57, 69, 57, 15);
        contentPane.add(lblTo);

        textField = new JTextField();
        textField.setBounds(125, 30, 191, 21);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(125, 66, 191, 21);
        contentPane.add(textField_1);

        btnNewButton = new JButton("찾아보기");
        btnNewButton.setBounds(328, 29, 97, 23);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(this);

        btnNewButton_1 = new JButton("찾아보기");
        btnNewButton_1.setBounds(328, 65, 97, 23);
        contentPane.add(btnNewButton_1);
        btnNewButton_1.addActionListener(this);

        JButton btnNewButton_2 = new JButton("복사 시작");
        btnNewButton_2.setBounds(196, 121, 97, 23);
        contentPane.add(btnNewButton_2);
        btnNewButton_2.addActionListener(e -> {

            try {
                InputStream inputStream = new FileInputStream(textField.getText());
                OutputStream outputStream = new FileOutputStream(textField_1.getText());
                int c;

                while ((c = inputStream.read()) != -1) {
                    outputStream.write(c);
                }
                inputStream.close();
                outputStream.close();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MyFrame frame = new MyFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        int i = fc.showOpenDialog(this);
        if (i == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            filepath = f.getPath();
            if (e.getSource() == btnNewButton) {
                textField.setText(filepath);
            } else {
                textField_1.setText(filepath);
            }
        }
    }
}