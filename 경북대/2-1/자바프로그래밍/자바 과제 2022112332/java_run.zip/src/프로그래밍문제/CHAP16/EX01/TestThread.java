package 프로그래밍문제.CHAP16.EX01;

class MyRunnable implements Runnable {
    String myName;

    public MyRunnable(String name) {
        myName = name;
    }

    public void run() {
        for (int i = 10; i >= 0; i--)
            System.out.print(myName + i + " ");
    }
}

public class TestThread {
    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(new MyRunnable("A"));
        Thread t2 = new Thread(new MyRunnable("B"));
        Thread t3 = new Thread(new MyRunnable("C"));
        t1.start();
        t1.join();
        t2.start();
        t2.join();
        t3.start();
        t3.join();
    }
}
