package 프로그래밍문제.CHAP16.EX02;


import javax.swing.*;
import java.awt.*;
import java.util.Calendar;

public class Clock extends JFrame implements Runnable {
    Thread runner;
    Font clockFont;

    public Clock() {
        setSize(350, 100);
        setVisible(true);
        setResizable(false);

        clockFont = new Font("Serif", Font.BOLD, 40);

        Container contentArea = getContentPane();
        ClockPanel timeDisplay = new ClockPanel();

        contentArea.add(timeDisplay);
        setContentPane(contentArea);
        start();

    }

    public static void main(String[] args) {
        Clock eg = new Clock();
    }

    public String timeNow() {
        Calendar now = Calendar.getInstance();
        int day = now.get(Calendar.DATE);
        int month = now.get(Calendar.MONTH);
        int hrs = now.get(Calendar.HOUR_OF_DAY);
        int min = now.get(Calendar.MINUTE);
        int sec = now.get(Calendar.SECOND);

        String time = month+"."+day + " " + hrs + ":" + min + ":" + sec;

        return time;
    }


    public void start() {
        if (runner == null) runner = new Thread(this);
        runner.start();
    }


    public void run() {
        while (runner == Thread.currentThread()) {
            repaint();

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("Thread failed");
            }

        }
    }

    class ClockPanel extends JPanel {
        public void paintComponent(Graphics painter) {
            painter.setFont(clockFont);
            painter.setColor(Color.black);
            painter.drawString(timeNow(), 60, 40);
        }
    }
}