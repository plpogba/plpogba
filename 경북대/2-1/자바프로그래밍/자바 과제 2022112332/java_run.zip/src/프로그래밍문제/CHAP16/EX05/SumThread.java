package 프로그래밍문제.CHAP16.EX05;

public class SumThread extends Thread {
    private int lo, hi;
    private int[] arr;
    private int ans = 0;
    private int mu = 1;
    public SumThread(int[] arr, int lo, int hi) {
        this.lo = lo;
        this.hi = hi;
        this.arr = arr;
    }

    public static int sum(int[] arr) throws InterruptedException {
        int len = arr.length;
        int ans = 0;

        SumThread[] ts = new SumThread[4];
        for (int i = 0; i < 4; i++) {
            ts[i] = new SumThread(arr, (i * len) / 4, ((i + 1) * len / 4));
            ts[i].start();
        }

        for (int i = 0; i < 4; i++) {
            ts[i].join();
            ans += ts[i].ans;
        }
        return ans;
    }
    public static int mul(int[] arr) throws InterruptedException {
        int len = arr.length;
        int ans = 1;

        SumThread[] ts = new SumThread[4];
        for (int i = 0; i < 4; i++) {
            ts[i] = new SumThread(arr, (i * len) / 4, ((i + 1) * len / 4));
            ts[i].start();
        }

        for (int i = 0; i < 4; i++) {
            ts[i].join();
            ans *= ts[i].ans;
        }
        return ans;
    }

    public static void main(String[] args) throws InterruptedException {
        int[] arr = new int[100];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = i;
        }
        //int sum = sum(arr);
        int mul = mul(arr);
        //System.out.println("합계: " + sum);
        System.out.println("곱: " + mul);
    }

    @Override
    public void run() {
        for (int i = lo; i < hi; i++) {
            mu *= arr[i];
        }
    }

}