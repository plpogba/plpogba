package 프로그래밍문제.CHAP16.EX06;

public class MaxThread extends Thread {
    private int lo, hi;
    private int[] arr;
    private int ans = 0;

    public MaxThread(int[] arr, int lo, int hi) {
        this.lo = lo;
        this.hi = hi;
        this.arr = arr;
    }

    public static int max(int[] arr) throws InterruptedException {
        int len = arr.length;
        int ans = 0;

        MaxThread[] ts = new MaxThread[4];
        for (int i = 0; i < 4; i++) {
            ts[i] = new MaxThread(arr, (i * len) / 4, ((i + 1) * len / 4));
            ts[i].start();
        }
        ans = 10000;
        for (int i = 0; i < 4; i++) {
            ts[i].join();
            if (ans > ts[i].ans)
                ans = ts[i].ans;
        }
        return ans;
    }

    public static void main(String[] args) throws InterruptedException {
        int[] arr = new int[100];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = i;
        }
        int m = max(arr);
        System.out.println("최소값: " + m);
    }

    @Override
    public void run() {
        ans = arr[lo];
        for (int i = lo; i < hi; i++) {
            if (ans < arr[i])
                ans = arr[i];
        }
    }
}
