package 프로그래밍문제.CHAP16.EX07;


import javax.swing.*;

public class CarGame extends JFrame {

    public CarGame() throws InterruptedException {
        setTitle("Running Race");
        setSize(600, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        Thread t1 = new MyThread("human1.png", 0, 0);
        Thread t2 = new MyThread("human2.png", 350, 0);
        t1.start();
        setVisible(true);
        t1.join();
        t2.start();
    }

    public static void main(String[] args) throws InterruptedException {
        CarGame t = new CarGame();
    }

    class MyThread extends Thread {
        private JLabel label;
        private int x, y;

        public MyThread(String fname, int x, int y) {
            this.x = x;
            this.y = y;
            label = new JLabel();
            label.setIcon(new ImageIcon(fname));
            label.setBounds(x, y, 100, 100);
            add(label);
        }

        public void run() {
            for (int i = 0; i < 100; i++) {
                x += 3;
                label.setBounds(x, y, 100, 100);
                repaint();
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}