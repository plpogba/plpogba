package 프로그래밍문제.CHAP16.EX10;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyFrame extends JFrame {
    Image image;

    MyFrame() {
        MyPanel p = new MyPanel();
        add(p);
        setSize(600, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        (new Thread(p)).start();
        setVisible(true);
    }

    public static void main(String[] args) {
        new MyFrame();
    }

    class RainDrop {
        int x;
        int y;

        public RainDrop(int x, int y) {
            super();
            this.x = x;
            this.y = y;
        }
    }

    class MyPanel extends JPanel implements Runnable {
        ArrayList<RainDrop> list = new ArrayList<>();

        MyPanel() {
            ImageIcon icon = new ImageIcon("umbrella.png");
            image = icon.getImage();
            this.setLayout(null);
            for (int i = 0; i < 80; i++) {
                int x = (int) (Math.random() * 600);
                int y = (int) (Math.random() * 300);
                list.add(new RainDrop(x, y));
            }
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(image, 300, 100, this);
            g.setColor(Color.GRAY);
            for (int i = 0; i < list.size(); i++) {
                RainDrop r = list.get(i);
                g.fillOval((int) r.x, (int) r.y, 5, 10);
            }
        }

        public void run() {
            while (true) {
                for (int i = 0; i < list.size(); i++) {
                    RainDrop r = list.get(i);
                    r.y += (int) (Math.random() * 10);
                    if (r.y > 500) r.y = 0;
                    list.set(i, r);
                }
                repaint();
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
