package 프로그래밍문제.CHAP16.EX11;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyFrame extends JFrame {
    MyFrame() {
        MyPanel p = new MyPanel();
        add(p);
        setSize(600, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        (new Thread(p)).start();
        setVisible(true);
    }

    public static void main(String[] args) {
        new MyFrame();
    }

    class RainDrop {
        int x;
        int w;
        int h;
        int y;

        public RainDrop(int x, int y, int w, int h) {
            super();
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    class MyPanel extends JPanel implements Runnable {
        ArrayList<RainDrop> list = new ArrayList<>();

        MyPanel() {
            this.setLayout(null);
            for (int i = 0; i < 80; i++) {
                int x = (int) (Math.random() * 600);
                int y = (int) (Math.random() * 300);
                list.add(new RainDrop(x, y, 10, 10));
            }
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, 600, 300);
            g.setColor(Color.WHITE);
            for (int i = 0; i < list.size(); i++) {
                RainDrop r = list.get(i);
                g.fillOval((int) r.x, (int) r.y, r.w, r.h);
            }
        }

        public void run() {
            while (true) {
                for (int i = 0; i < list.size(); i++) {
                    RainDrop r = list.get(i);
                    r.w = (int) (Math.random() * 50);
                    r.h = r.w;
                    list.set(i, r);
                }
                repaint();
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}