package 프로그래밍문제.CHAP17.EX02;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Client extends JFrame {

    private JPanel contentPane;
    private JTextField txtLocalhost;
    private JTextField textField_1;
    private JTextField textField;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    /**
     * Create the frame.
     *
     * @throws IOException
     */
    public Client() throws IOException {
        setTitle("\uAC04\uB2E8\uD55C TCP Chat");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Host IP");
        lblNewLabel.setBounds(43, 26, 57, 15);
        contentPane.add(lblNewLabel);

        txtLocalhost = new JTextField();
        txtLocalhost.setText("localhost");
        txtLocalhost.setBounds(126, 23, 116, 21);
        contentPane.add(txtLocalhost);
        txtLocalhost.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Port");
        lblNewLabel_1.setBounds(43, 62, 57, 15);
        contentPane.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setText("5000");
        textField_1.setBounds(126, 59, 116, 21);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JRadioButton rdbtnNewRadioButton = new JRadioButton("Host");
        rdbtnNewRadioButton.setBounds(43, 113, 74, 23);
        contentPane.add(rdbtnNewRadioButton);

        JRadioButton rdbtnGuest = new JRadioButton("Guest");
        rdbtnGuest.setSelected(true);
        rdbtnGuest.setBounds(43, 148, 74, 23);
        contentPane.add(rdbtnGuest);

        ButtonGroup group = new ButtonGroup();
        group.add(rdbtnNewRadioButton);
        group.add(rdbtnGuest);

        JTextArea textArea = new JTextArea();
        textArea.setBounds(270, 10, 152, 182);
        contentPane.add(textArea);

        textField = new JTextField();
        textField.setText("\uC548\uB155\uD558\uC138\uC694?");
        textField.setBounds(270, 210, 152, 21);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("\uC5F0\uACB0");
        btnNewButton.setBounds(49, 209, 97, 23);
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("\uC5F0\uACB0\uB04A\uAE30");
        btnNewButton_1.setBounds(158, 209, 97, 23);
        contentPane.add(btnNewButton_1);

        btnNewButton.addActionListener(e -> {
            try {
                if (rdbtnNewRadioButton.isSelected()) {
                    serverSocket = new ServerSocket(Integer.parseInt(textField_1.getText()));
                    clientSocket = serverSocket.accept();
                    out = new PrintWriter(clientSocket.getOutputStream());
                    in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                } else {
                    clientSocket = new Socket(txtLocalhost.getText(), Integer.parseInt(textField_1.getText()));
                    out = new PrintWriter(clientSocket.getOutputStream());
                    in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                }
            } catch (NumberFormatException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        });

        textField.addActionListener(e -> {
            String msg = textField.getText();
            out.println(msg);
            out.flush();
            textArea.append(msg + "\n");
        });
        Thread receiver = new Thread(new Runnable() {
            String msg;

            @Override
            public void run() {
                try {
                    while (in == null) {
                        Thread.sleep(100);
                    }

                    msg = in.readLine();
                    while (msg != null) {
                        textArea.append(msg + "\n");
                        msg = in.readLine();
                    }
                    System.out.println("Client out of service");
                    out.close();
                    clientSocket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        receiver.start();

    }

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Client frame = new Client();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}