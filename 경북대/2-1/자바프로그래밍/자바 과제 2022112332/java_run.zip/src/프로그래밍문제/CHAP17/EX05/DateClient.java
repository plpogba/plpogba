package 프로그래밍문제.CHAP17.EX05;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

// 소스를 입력하고 Ctrl+Shift+O를 눌러서 필요한 파일을 포함한다.
public class DateClient {

    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 9100);
        BufferedReader input =
                new BufferedReader(new InputStreamReader(s.getInputStream()));
        String res = input.readLine();
        System.out.println(res);
        System.exit(0);
    }
}

