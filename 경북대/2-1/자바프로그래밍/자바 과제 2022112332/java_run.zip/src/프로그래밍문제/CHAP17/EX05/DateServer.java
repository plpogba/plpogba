package 프로그래밍문제.CHAP17.EX05;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

// 소스를 입력하고 Ctrl+Shift+O를 눌러서 필요한 파일을 포함한다.
public class DateServer {

    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(9100);
        try {
            while (true) {
                Socket socket = ss.accept();
                try {
                    PrintWriter out = new PrintWriter(socket.getOutputStream(),
                            true);
                    String date = new String();
                    out.printf("Month: %d date: %d\n", new Date().getMonth(), new Date().getDate());
                } finally {
                    socket.close();
                }
            }
        } finally {
            ss.close();
        }
    }
}