package 프로그래밍문제.CHAP17.EX07;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;

public class Client {
    private static DataOutputStream os = null;
    private static DataInputStream is = null;

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 6000)) {
            is = new DataInputStream(socket.getInputStream());
            os = new DataOutputStream(socket.getOutputStream());

            sendFile("dog.jpg");

            is.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void sendFile(String path) throws Exception {
        int bytes = 0;
        File file = new File(path);
        FileInputStream fis = new FileInputStream(file);

        os.writeLong(file.length());
        byte[] buffer = new byte[4 * 1024];
        while ((bytes = fis.read(buffer)) != -1) {
            os.write(buffer, 0, bytes);
            os.flush();
        }
        fis.close();
    }
}