package 프로그래밍문제.CHAP17.EX07;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private static DataOutputStream os = null;
    private static DataInputStream is = null;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(6000)) {
            Socket clientSocket = serverSocket.accept();
            System.out.println(clientSocket + " 연결되었습니다.");
            is = new DataInputStream(clientSocket.getInputStream());
            os = new DataOutputStream(clientSocket.getOutputStream());

            receiveFile("dog1.jpg");

            is.close();
            os.close();
            clientSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void receiveFile(String fileName) throws Exception {
        int bytes = 0;
        FileOutputStream fos = new FileOutputStream(fileName);

        long size = is.readLong();
        byte[] buffer = new byte[4 * 1024];
        while (size > 0 && (bytes = is.read(buffer, 0, (int) Math.min(buffer.length, size))) != -1) {
            fos.write(buffer, 0, bytes);
            size -= bytes;
        }
        fos.close();
    }
}