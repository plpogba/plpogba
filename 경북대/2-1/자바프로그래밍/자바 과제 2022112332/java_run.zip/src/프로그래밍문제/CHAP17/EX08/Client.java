package 프로그래밍문제.CHAP17.EX08;

import javax.swing.*;
import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;

public class Client extends JFrame {
    private static DataOutputStream os = null;
    private static DataInputStream is = null;
    JButton button1;
    JButton button2;
    JTextField text;

    public Client() throws Exception {
        super();
        setTitle("File Transfer Client");
        setSize(300, 200);
        setLayout(new FlowLayout());
        button1 = new JButton("파일 선택");
        button2 = new JButton("파일 전송");
        text = new JTextField(20);
        text.setText("dog.png");
        add(text);
        add(button1);
        add(button2);
        button2.addActionListener(e -> {
            Socket socket;
            try {
                socket = new Socket("localhost", 5000);
                is = new DataInputStream(socket.getInputStream());
                os = new DataOutputStream(socket.getOutputStream());

                int bytes = 0;
                File file = new File(text.getText());
                FileInputStream fis = new FileInputStream(file);

                os.writeLong(file.length());
                byte[] buffer = new byte[4 * 1024];
                while ((bytes = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytes);
                    os.flush();
                }
                fis.close();
                is.close();
                os.close();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) throws Exception {
        new Client();
    }
}