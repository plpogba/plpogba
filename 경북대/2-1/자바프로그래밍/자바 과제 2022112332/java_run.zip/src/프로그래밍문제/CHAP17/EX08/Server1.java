package 프로그래밍문제.CHAP17.EX08;

import javax.swing.*;
import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server1 extends JFrame {
    private static DataOutputStream os = null;
    private static DataInputStream is = null;
    Image img;

    public Server1() {
        super();
        setTitle("File Transfer Server");
        setSize(600, 400);
        add(new MyPanel());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            Socket clientSocket = serverSocket.accept();
            System.out.println(clientSocket + " 연결되었습니다.");
            is = new DataInputStream(clientSocket.getInputStream());
            os = new DataOutputStream(clientSocket.getOutputStream());

            receiveFile("dog1.jpg");
            ImageIcon icon = new ImageIcon("dog1.jpg");
            img = icon.getImage(); // 이미지 아이콘 객체에서 이미지를 추출한다.
            is.close();
            os.close();
            repaint();
            clientSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Server1();
    }

    private static void receiveFile(String fileName) throws Exception {
        int bytes = 0;
        FileOutputStream fos = new FileOutputStream(fileName);

        long size = is.readLong();
        byte[] buffer = new byte[4 * 1024];
        while (size > 0 && (bytes = is.read(buffer, 0, (int) Math.min(buffer.length, size))) != -1) {
            fos.write(buffer, 0, bytes);
            size -= bytes;
        }
        fos.close();
    }

    class MyPanel extends JPanel {
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (img != null)
                g.drawImage(img, 0, 0, null); // 이미지를 화면의 원점에 그린다.
        }
    }
}