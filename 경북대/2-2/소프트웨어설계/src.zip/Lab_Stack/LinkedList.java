package Lab_Stack;

public class LinkedList{
    private final Node head = new Node();
    private Node lastNode = head;
    private int ListLength = 0;

    Node insertNode(Object ob, Node targetNode){
        Node newNode = new Node();
        newNode.setNode(ob);
        newNode.connectLink(targetNode.getNextNode());
        targetNode.connectLink(newNode);

        if(targetNode == this.getLastNode())
            this.lastNode = newNode;
        else
            ListLength += 1;

        return newNode;
    }
    void appendNode(Object ob){
        lastNode = this.insertNode(ob, this.getLastNode());
        ListLength += 1;
    }
    void deleteNode(int index){
        Node prev = null;
        Node cur = this.head;
        if(index == -1 && this.getListLength() != 0){
           while(cur.getNextNode() != this.getLastNode()){
               cur = cur.getNextNode();
           }
           cur.disconnectLink();
           lastNode = cur;
           ListLength-=1;
        }
        else if(index == 0){
            System.out.println("Cannot delete head");
        }
        else if(index > ListLength || index < -1)
            System.out.println("Incorrect index");
        else{
            for(int i = 0; i<index; i++){
                prev = cur;
                cur = cur.getNextNode();
            }

            if(prev != null){
                prev.connectLink(cur.getNextNode());
                cur.disconnectLink();
                if(cur.getNextNode() == lastNode)
                    lastNode = cur;
                ListLength -= 1;
            }
            else{
                System.out.println("EmptyList");
            }
        }
    }
    int getListLength(){
        return ListLength;
    }
    
    Node getNode(int index){
        Node tmp = head;
        for(int i=0; i<index; i++)
            tmp=tmp.getNextNode();
        return tmp;
    }
    Node getLastNode(){
        return lastNode;
    }
    String getStringOfList(){
        StringBuilder s = new StringBuilder();
        if(this.getListLength() > 0){
            for(Node i = this.head.getNextNode(); i != null; i = i.getNextNode()){
                s.append(i.getItem().toString());
                s.append(' ');
            }
        }
        return "LinkedList: " + s;
    }


}

