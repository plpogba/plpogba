package Lab_Stack;

public class Node{
    private Object ob = null;
    private Node link = null;

    Object getItem(){
        return this.ob;
    }
    Node getNextNode(){
        return this.link;
    }
    void setNode(Object x){
        this.ob = x;
    }

    void connectLink(Node a){
        this.link = a;
    }
    void disconnectLink(){
        this.link = null;
    }
}