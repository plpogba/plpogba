package Lab_Stack;

public class Stack {
    private final LinkedList st = new LinkedList();
    public void push(Object ob){
        st.appendNode(ob);
    }

    public Object pop(){
        Object tmp = null;
        if(!this.isEmpty()) {
            tmp = st.getLastNode().getItem();
            st.deleteNode(-1);
        }
        else
            System.out.println("EmptyStack: Nothing to pop");
        return tmp;
    }

    public boolean isEmpty(){
        return st.getListLength() == 0;
    }

    public boolean isFull(){
        return false;
    }

    public String toString(){
        return st.getStringOfList();
    }
}

