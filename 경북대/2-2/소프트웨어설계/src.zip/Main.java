import Lab_Stack.Stack;

public class Main {
    public static void main(String[] args) {
        Stack st = new Stack();
        st.push("abc");
        System.out.println(st);
        st.push(2);
        System.out.println(st);
        st.push('a');
        System.out.println(st);
        System.out.println("isFull? "+ st.isFull());
        while(!st.isEmpty()){
            System.out.println("pop: " + st.pop());
        }
        System.out.println(st);
        System.out.println("isEmpty? "+ st.isEmpty());
    }
}