#include <Keypad.h>
#include <SoftwareSerial.h>
#include <ThreeWire.h> 
#include <RtcDS1302.h>
#include <SPI.h>
#include <SD.h>

#define countof(a) (sizeof(a) / sizeof(a[0]))
#define sensor 10

//RTC모듈에 필요한 전역
ThreeWire myWire(16, 17, 18);  // IO, SCLK, CE
RtcDS1302<ThreeWire> Rtc(myWire);

//키패드, 솔레노이드, 블루투스 전역
SoftwareSerial bluetooth(14, 15); // TX, RX
int randNumber;
int count = 0;

char hexaKeys[4][3] = {
  { '1', '2', '3' },
  { '4', '5', '6' },
  { '7', '8', '9' },
  { '*', '0', '#' }
};

//10번 핀 고장나서 임시로 2번핀 사용
byte rowPins[4] = { 19, 6, 5, 3 };  //connect to the row pinouts of the keypad
byte colPins[3] = { 8, 9, 2 };     //connect to the column pinouts of the keypad

//initialize an instance of class NewKeypad
Keypad customKeypad = Keypad(makeKeymap(hexaKeys), rowPins, colPins, 4, 3);

String S;     // 키패드 입력받을 변수
String PSWD;  // 패스워드

void setup() {
  Serial.begin(9600);
  bluetooth.begin(9600);
  pinMode(sensor, OUTPUT);
  RTCsetup();
  pinMode(A5, INPUT);
  pinMode(7, OUTPUT);
  randomSeed(analogRead(0));
  randNumber  = random(1000, 10000);

  if (!SD.begin(4)) {
    Serial.println("initialization failed!");
    while (1);
  }
  Serial.println("initialization done.");
}

//박동하
//RTC모듈 셋업
void RTCsetup() {

  /*Serial.begin(57600);

  Serial.print("compiled: ");
  Serial.print(__DATE__);
  Serial.println(__TIME__);*/

  pinMode(A2, INPUT);
  pinMode(A3, INPUT);
  pinMode(A4, INPUT);

  Rtc.Begin();

  RtcDateTime compiled = RtcDateTime(__DATE__, __TIME__);
  //saveDateTime(compiled);
  //Serial.println();

  if (!Rtc.IsDateTimeValid()) {
    // Common Causes:
    //    1) first time you ran and the device wasn't running yet
    //    2) the battery on the device is low or even missing

    //Serial.println("RTC lost confidence in the DateTime!");
    Rtc.SetDateTime(compiled);
  }

  if (Rtc.GetIsWriteProtected()) {
    //Serial.println("RTC was write protected, enabling writing now");
    Rtc.SetIsWriteProtected(false);
  }

  if (!Rtc.GetIsRunning()) {
    //Serial.println("RTC was not actively running, starting now");
    Rtc.SetIsRunning(true);
  }

  RtcDateTime now = Rtc.GetDateTime();
  if (now < compiled) {
    //Serial.println("RTC is older than compile time!  (Updating DateTime)");
    Rtc.SetDateTime(compiled);
  } else if (now > compiled) {
    //Serial.println("RTC is newer than compile time. (this is expected)");
  } else if (now == compiled) {
    //Serial.println("RTC is the same as compile time! (not expected but all is fine)");
  }
}

//김지호
void opening() {
  PSWD = String(randNumber);  // 비밀번호 설정
  PSWD += '#';
  char Key = customKeypad.getKey();  //입력받은 키 저장

  if (Key) {
    S += Key;  //Key를 문자열에 저장
  }

  if (Key == '#') {  // '#'이 눌릴경우 비밀번호와 비교하여 이후 동작
    if (S == PSWD) {
      digitalWrite(sensor, HIGH);
      delay(2000);
      digitalWrite(sensor, LOW);
      delay(2000);
      count = 0;
    } 
    else
    {
      count++;
    }

    if(count == 3){
      digitalWrite(7, HIGH);
      delay(1000);
      digitalWrite(7, LOW);
      delay(1000);
      count = 0;
    }

    S = "";  // 다음 동작을 위해 저장값 초기화
    RtcDateTime now = Rtc.GetDateTime(); //키패드 입력이 틀리던 말던, 입력이 감지되면 타임로그 txt파일에 저장.
    saveDateTime(now);
  }
}

//박동하
//시간을 문자열의 형태로 바꾸어 저장
void saveDateTime(const RtcDateTime& dt) {
  char datestring[20];

  snprintf_P(datestring,
             countof(datestring),
             PSTR("%04u/%02u/%02u %02u:%02u:%02u"),
             dt.Year(),
             dt.Month(),
             dt.Day(),             
             dt.Hour(),
             dt.Minute(),
             dt.Second());
  String s = "text";
  s += dt.DayOfWeek();
  s += ".txt";
  File myFile = SD.open(s, FILE_WRITE);
  if(myFile){
    myFile.println(datestring);
  }
  myFile.close();
}

//박동하
//비밀번호를 앱으로 전송해주는 함수
void bluetooth_app(int n) {
  //앱에서 번호 달라고 하면 randNumber에 랜덤값 생성해서 저장
  if (n == 7) {
    randNumber = random(1000, 10000);
    bluetooth.print("비밀번호: ");
    bluetooth.print(randNumber);
  }
}

//박동하
//타임로그를 앱으로 전송해주는 함수
void send_timeLog(int n) {
  String s = "text";
  s += String(n);
  s += ".txt";

  File myFile = SD.open(s);

  if (myFile) {
    char sd;
    String data;
    while (myFile.available()) {
      sd = (char)myFile.read();
      data += sd;
    }
    bluetooth.print(data);
  }
  myFile.close();
}

void loop() {
  //앱에서 값을 요청하면 그 값에 따라 함수 실행
  if (bluetooth.available()) {
    int n = bluetooth.read() - '0';
    if (n < 7)
      send_timeLog(n);
    else
      bluetooth_app(n);
  }
  opening();
}