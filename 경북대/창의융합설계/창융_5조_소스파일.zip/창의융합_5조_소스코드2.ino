//강진우 아두이노 camera2SD

#include <Wire.h>
#include <SD.h>
int CS_Pin = 10;
String type = String(".bmp");
int i = 1;
int prev = 0;

/////강진우/////////////////
void Init_YUV422() {
  WriteOV7670(0x12, 0x00);  //COM7
  WriteOV7670(0x8C, 0x00);  //RGB444
  WriteOV7670(0x04, 0x00);  //COM1
  WriteOV7670(0x40, 0xC0);  //COM15
  WriteOV7670(0x14, 0x1A);  //COM9
  WriteOV7670(0x3D, 0x40);  //COM13
}
/////강진우/////////////////
void Init_QVGA() {
  WriteOV7670(0x0C, 0x04);  //COM3 - Enable Scaling
  WriteOV7670(0x3E, 0x19);  //COM14
  WriteOV7670(0x72, 0x11);  //
  WriteOV7670(0x73, 0xF1);  //
  WriteOV7670(0x17, 0x16);  //HSTART
  WriteOV7670(0x18, 0x04);  //HSTOP
  WriteOV7670(0x32, 0xA4);  //HREF
  WriteOV7670(0x19, 0x02);  //VSTART
  WriteOV7670(0x1A, 0x7A);  //VSTOP
  WriteOV7670(0x03, 0x0A);  //VREF
}
/////강진우/////////////////
void Init_OV7670() {
  //Reset All Register Values
  WriteOV7670(0x12, 0x80);
  delay(100);
  WriteOV7670(0x3A, 0x04);  //TSLB

  WriteOV7670(0x13, 0xC0);  //COM8
  WriteOV7670(0x00, 0x00);  //GAIN
  WriteOV7670(0x10, 0x00);  //AECH
  WriteOV7670(0x0D, 0x40);  //COM4
  WriteOV7670(0x14, 0x18);  //COM9
  WriteOV7670(0x24, 0x95);  //AEW
  WriteOV7670(0x25, 0x33);  //AEB
  WriteOV7670(0x13, 0xC5);  //COM8
  WriteOV7670(0x6A, 0x40);  //GGAIN
  WriteOV7670(0x01, 0x40);  //BLUE
  WriteOV7670(0x02, 0x60);  //RED
  WriteOV7670(0x13, 0xC7);  //COM8
  WriteOV7670(0x41, 0x08);  //COM16
  WriteOV7670(0x15, 0x20);  //COM10 - PCLK does not toggle on HBLANK
}
/////강진우/////////////////
void WriteOV7670(byte regID, byte regVal) {
  Wire.beginTransmission(0x21);
  Wire.write(regID);
  Wire.write(regVal);
  Wire.endTransmission();
  delay(1);
}
/////강진우/////////////////
void ReadOV7670(byte regID) {
  Wire.beginTransmission(0x21);  // 7-bit Slave address
  Wire.write(regID);             // reading from register 0x11
  Wire.endTransmission();

  // Step 2: Read 1 byte from Slave
  Wire.requestFrom(0x21, 1);
  Serial.print("Read request Status:");
  Serial.println(Wire.available());
  Serial.print(regID, HEX);
  Serial.print(":");
  Serial.println(Wire.read(), HEX);
}
/////강진우/////////////////
void XCLK_SETUP(void) {
  pinMode(9, OUTPUT);  //Set pin 9 to output
  TCCR1A = (1 << COM1A0) | (1 << WGM11) | (1 << WGM10);
  TCCR1B = (1 << WGM13) | (1 << WGM12) | (1 << CS10);
  OCR1A = 0;
}
/////강진우/////////////////
void TWI_SETUP(void) {
  TWSR &= ~3;
  TWBR = 72;
}
/////강진우/////////////////
void OV7670_PINS(void) {
  DDRC &= ~15;  //low d0-d3 camera
  DDRD &= ~252;
}


/////강진우/////////////////
void QVGA_Image(String title) {
  int h, w;

  File dataFile = SD.open(title, FILE_WRITE);
  while (!(PIND & 8))
    ;  
  while ((PIND & 8))
    ; 

  h = 240;
  while (h--) {
    w = 320;
    byte dataBuffer[320];
    while (w--) {
      while ((PIND & 4))
        ;  
      dataBuffer[319 - w] = (PINC & 15) | (PIND & 240);
      while (!(PIND & 4))
        ; 
      while ((PIND & 4))
        ;  
      while (!(PIND & 4))
        ;  
    }
    dataFile.write(dataBuffer, 320);
  }

  dataFile.close();
  delay(100);
}

void setup() {

  noInterrupts();  
  XCLK_SETUP();    
  OV7670_PINS();  
  delay(1000);
  TWI_SETUP();  
  interrupts();
  Wire.begin();


  Init_OV7670();
  Init_QVGA();
  Init_YUV422();
  WriteOV7670(0x11, 0x1F);  
  noInterrupts();
  Serial.begin(9600);
  pinMode(8, INPUT_PULLUP);
  pinMode(CS_Pin, OUTPUT);
  SD.begin(CS_Pin);
}

/////강진우/////////////////
void loop() {

  if (digitalRead(8) == LOW) {
    prev = 1;
    Serial.println("c");
  }
  if (prev) {
    prev = 0;
    QVGA_Image(String(i + type));
    i++;
    QVGA_Image(String(i + type));
    i++;
    QVGA_Image(String(i + type));
    i++;
    QVGA_Image(String(i + type));
    i++;
    QVGA_Image(String(i + type));
    i++;
    QVGA_Image(String(i + type));
    i++;

  }
}
